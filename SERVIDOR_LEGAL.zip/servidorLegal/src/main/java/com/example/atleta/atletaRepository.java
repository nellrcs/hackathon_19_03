package com.example.atleta;

import org.springframework.data.jpa.repository.JpaRepository;

public interface atletaRepository extends JpaRepository<Atleta, String>{

}
