package com.example.atleta;

import java.util.UUID;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Atleta {
	
	@Id
	private String id;
	private String codigoAtleta;
	private String name;
	private int idade;
	private String CPF;
	
	public Atleta(){
		this.id=UUID.randomUUID().toString();
	}
	
	public Atleta(String codigoAtleta, String name, int idade, String CPF) {
		this();
		this.codigoAtleta = codigoAtleta;
		this.name = name;
		this.idade = idade;
		this.CPF = CPF;
	}
	public String getCodigoAtleta() {
		return codigoAtleta;
	}
	public void setCodigoAtleta(String codigoAtleta) {
		this.codigoAtleta = codigoAtleta;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	public String getCPF() {
		return CPF;
	}
	public void setCPF(String CPF) {
		this.CPF = CPF;
	}
	public String getId() {
		return id;
	}

}